package com.altech.spring.springjdbc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.altech.spring.springjdbc.employee.dao.EmployeeDao;
import com.altech.spring.springjdbc.employee.dto.Employee;

public class Test {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
		EmployeeDao empDao = (EmployeeDao) context.getBean("employeeDao");
		Employee employee = new Employee();
		employee.setId(103);
		employee.setFirstName("Gyanendra");
		employee.setLastName("Yadav");

		int result = empDao.create(employee);
		System.out.println("Number of records inserted are: " + result);

	}

}
