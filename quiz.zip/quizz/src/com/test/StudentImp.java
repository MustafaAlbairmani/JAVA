package com.test;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

import com.student.Student;

public class StudentImp {
    public static void main(String[] args) {
        Student student = new Student();
        Scanner scanner = new Scanner(System.in);

        // Read student details from user
        System.out.println("Please enter the student's details.");

        System.out.print("Roll Number: ");
        student.setRollNo(scanner.nextInt());
        scanner.nextLine(); // Consume newline

        System.out.print("Name: ");
        student.setName(scanner.nextLine());

        System.out.print("Marks for Subject 1: ");
        student.setSubject1(scanner.nextInt());

        System.out.print("Marks for Subject 2: ");
        student.setSubject2(scanner.nextInt());

        System.out.print("Marks for Subject 3: ");
        student.setSubject3(scanner.nextInt());

        // Calculate total and save to file
        student.calcTotal();
        writeStudentToFile(student);

        // Read from file and display
        Student readStudent = readStudentFromFile();
        if (readStudent != null) {
            readStudent.printStudInfo();
        }
    }

    private static void writeStudentToFile(Student student) {
        try (ObjectOutputStream out = new ObjectOutputStream(
                new FileOutputStream("StudentInfo.txt"))) {
            out.writeObject(student);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static Student readStudentFromFile() {
        try (ObjectInputStream in = new ObjectInputStream(
                new FileInputStream("StudentInfo.txt"))) {
            return (Student) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }
}
