package com.student;

import java.util.Scanner;

public class Student implements StudentInt {
    private int rollNo;
    private String name;
    private int subject1;
    private int subject2;
    private int subject3;
    private int totalMarks;

    // Temporary Scanner for reading input
    private transient Scanner scanner = new Scanner(System.in);

    @Override
    public void readStudInfo() {
        // Implementation to read student info, e.g., from input
        System.out.print("Enter roll number: ");
        this.rollNo = this.scanner.nextInt(); // Read roll number
        this.scanner.nextLine(); // Consume newline left-over

        System.out.print("Enter name: ");
        this.name = this.scanner.nextLine(); // Read name

        System.out.print("Enter marks for Subject 1: ");
        this.subject1 = this.scanner.nextInt(); // Read marks for Subject 1

        System.out.print("Enter marks for Subject 2: ");
        this.subject2 = this.scanner.nextInt(); // Read marks for Subject 2

        System.out.print("Enter marks for Subject 3: ");
        this.subject3 = this.scanner.nextInt(); // Read marks for Subject 3
    }

    @Override
    public void calcTotal() {
        // Implementation to calculate total marks
        this.totalMarks = this.subject1 + this.subject2 + this.subject3;
    }

    @Override
    public void printStudInfo() {
        // Implementation to print student info
        System.out.println("Roll No: " + this.rollNo);
        System.out.println("Name: " + this.name);
        System.out.println("Total Marks: " + this.totalMarks);
    }

    // Getters and Setters for each property
    public int getRollNo() {
        return this.rollNo;
    }

    public void setRollNo(int rollNo) {
        this.rollNo = rollNo;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSubject1() {
        return this.subject1;
    }

    public void setSubject1(int subject1) {
        this.subject1 = subject1;
    }

    public int getSubject2() {
        return this.subject2;
    }

    public void setSubject2(int subject2) {
        this.subject2 = subject2;
    }

    public int getSubject3() {
        return this.subject3;
    }

    public void setSubject3(int subject3) {
        this.subject3 = subject3;
    }

    public int getTotalMarks() {
        return this.totalMarks;
    }

    // No need for a setter for totalMarks as it is calculated by calcTotal()

    // Make sure to close the scanner when it's no longer needed
    public void closeScanner() {
        if (this.scanner != null) {
            this.scanner.close();
        }
    }
}
