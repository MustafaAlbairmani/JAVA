
package com.student;

public interface StudentInt {
    void readStudInfo();
    void calcTotal();
    void printStudInfo();
}
