import java.util.ArrayList;
import java.util.List;

public class Item {
    private int itemId;
    private String itemName;

    // Constructor
    public Item(int itemId, String itemName) {
        this.itemId = itemId;
        this.itemName = itemName;
    }

    // Method to display item details
    public void displayItemDetails() {
        System.out.println(
                "Item ID: " + this.itemId + ", Item Name: " + this.itemName);
    }

    // Getters and Setters
    public int getItemId() {
        return this.itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public String getItemName() {
        return this.itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public static void main(String[] args) {
        final List<Item> itemList = new ArrayList<>();

        Thread writerThread = new Thread(() -> {
            synchronized (itemList) {
                itemList.add(new Item(1, "Item 1"));
                itemList.add(new Item(2, "Item 2"));
                itemList.add(new Item(3, "Item 3"));
                itemList.add(new Item(4, "Item 4"));
                itemList.add(new Item(5, "Item 5"));
                itemList.notify(); // Notify any waiting threads that the itemList is ready
            }
        });

        Thread readerThread = new Thread(() -> {
            synchronized (itemList) {
                try {
                    while (itemList.isEmpty()) {
                        itemList.wait(); // Wait until the itemList is not empty
                    }
                    itemList.forEach(Item::displayItemDetails);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt(); // Restore the interrupted status
                    System.out.println(
                            "Thread was interrupted, failed to complete operation");
                }
            }
        });

        writerThread.start();
        readerThread.start();
    }
}