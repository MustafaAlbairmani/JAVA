import java.io.*;

public class MainProgram {
    
    // User-defined exception for argument mismatch
    static class ArgumentMismatchException extends Exception {
        public ArgumentMismatchException(String message) {
            super(message);
        }
    }

    public static void main(String[] args) {
        try {
            // Check for 5 command line arguments
            if (args.length != 5) {
                throw new ArgumentMismatchException("Five numbers are required as command line arguments.");
            }

            // Check if NumberFile.txt exists
            File file = new File("NumberFile.txt");
            boolean append = file.exists();

            // Write the numbers to the file
            try (FileWriter fw = new FileWriter(file, append);
                 BufferedWriter bw = new BufferedWriter(fw)) {
                for (String num : args) {
                    bw.write(num + "\n");
                }
            }

            // Read and display the file contents
            try (FileReader fr = new FileReader(file);
                 BufferedReader br = new BufferedReader(fr)) {
                String line;
                while ((line = br.readLine()) != null) {
                    System.out.println(line);
                }
            }

        } catch (ArgumentMismatchException e) {
            System.err.println("Error: " + e.getMessage());
        } catch (IOException e) {
            System.err.println("An I/O error occurred: " + e.getMessage());
        }
    }
}
