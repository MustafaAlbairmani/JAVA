package com.bill;

public class RegularCustomer extends Customer {
    private int billNo;
    private float billAmount;

    public RegularCustomer(int custId, String custName, long mobileNumber, int billNo) {
        super(custId, custName, mobileNumber);
        this.billNo = billNo;
    }

    // Getters
    public int getBillNo() { return billNo; }
    public float getBillAmount() { return billAmount; }

    @Override
    public double calculateBill(int minutes) {
        if (minutes <= 30) {
            billAmount = minutes * 1.5f;
        } else {
            billAmount = 45 + (minutes - 30);
        }
        return billAmount;
    }
}

