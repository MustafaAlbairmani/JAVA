package com.bill;

public class PremiumCustomer extends Customer {
    private int billNo;
    private float billAmount;

    public PremiumCustomer(int custId, String custName, long mobileNumber, int billNo) {
        super(custId, custName, mobileNumber);
        this.billNo = billNo;
    }

    // Getters
    public int getBillNo() { return billNo; }
    public float getBillAmount() { return billAmount; }

    @Override
    public double calculateBill(int minutes) {
        if (minutes <= 30) {
            billAmount = minutes;
        } else {
            billAmount = 30 + (minutes - 30) * 0.5f;
        }
        return billAmount;
    }
}
