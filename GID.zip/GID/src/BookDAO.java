import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BookDAO {
    private String jdbcURL = "jdbc:mysql://localhost:3306/myBookDatabase?useSSL=false";
    private String jdbcUsername = "albairmani";
    private String jdbcPassword = "qwert1234";

    // SQL queries
    private static final String INSERT_BOOKS_SQL = "INSERT INTO books (bookID, bookTitle, bookPrice) VALUES (?, ?, ?);";
    private static final String SELECT_BOOK_BY_ID = "SELECT bookID, bookTitle, bookPrice FROM books WHERE bookID = ?";
    private static final String SELECT_ALL_BOOKS = "SELECT * FROM books";
    private static final String DELETE_BOOK_SQL = "DELETE FROM books WHERE bookID = ?";
    private static final String UPDATE_BOOK_SQL = "UPDATE books SET bookTitle = ?, bookPrice = ? WHERE bookID = ?;";

    // Create connection
    protected Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(this.jdbcURL,
                    this.jdbcUsername, this.jdbcPassword);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return connection;
    }

    // Create (Insert) book
    public void createBook(Book book) throws SQLException {
        try (Connection connection = this.getConnection();
                PreparedStatement preparedStatement = connection
                        .prepareStatement(INSERT_BOOKS_SQL)) {
            preparedStatement.setInt(1, book.getBookID());
            preparedStatement.setString(2, book.getBookTitle());
            preparedStatement.setDouble(3, book.getBookPrice());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            this.printSQLException(e);
        }
    }

    // Read (Select) book by ID
    public Book getBookById(int id) throws SQLException {
        Book book = null;
        try (Connection connection = this.getConnection();
                PreparedStatement preparedStatement = connection
                        .prepareStatement(SELECT_BOOK_BY_ID)) {
            preparedStatement.setInt(1, id);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int bookID = rs.getInt("bookID");
                String bookTitle = rs.getString("bookTitle");
                double bookPrice = rs.getDouble("bookPrice");
                book = new Book(bookID, bookTitle, bookPrice);
            }
        } catch (SQLException e) {
            this.printSQLException(e);
        }
        return book;
    }

    // Read (Select) all books
    public List<Book> getAllBooks() throws SQLException {
        List<Book> books = new ArrayList<>();
        try (Connection connection = this.getConnection();
                PreparedStatement preparedStatement = connection
                        .prepareStatement(SELECT_ALL_BOOKS)) {
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                int bookID = rs.getInt("bookID");
                String bookTitle = rs.getString("bookTitle");
                double bookPrice = rs.getDouble("bookPrice");
                books.add(new Book(bookID, bookTitle, bookPrice));
            }
        } catch (SQLException e) {
            this.printSQLException(e);
        }
        return books;
    }

    // Update book
    public boolean updateBook(Book book) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = this.getConnection();
                PreparedStatement statement = connection
                        .prepareStatement(UPDATE_BOOK_SQL)) {
            statement.setString(1, book.getBookTitle());
            statement.setDouble(2, book.getBookPrice());
            statement.setInt(3, book.getBookID());

            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    // Delete book
    public boolean deleteBook(int id) throws SQLException {
        boolean rowDeleted;
        try (Connection connection = this.getConnection();
                PreparedStatement statement = connection
                        .prepareStatement(DELETE_BOOK_SQL)) {
            statement.setInt(1, id);
            rowDeleted = statement.executeUpdate() > 0;
        }
        return rowDeleted;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println(
                        "SQLState: " + ((SQLException) e).getSQLState());
                System.err.println(
                        "Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}
