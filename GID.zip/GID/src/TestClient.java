import com.bill.Customer;
import com.bill.PremiumCustomer;
import com.bill.RegularCustomer;
import java.util.Scanner;

public class TestClient {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Customer[] customers = new Customer[2];

        // Input for Premium Customer
        System.out.println("Enter details for Premium Customer:");
        System.out.print("Customer ID: ");
        int custId = scanner.nextInt();
        System.out.print("Customer Name: ");
        scanner.nextLine(); // consume newline
        String custName = scanner.nextLine();
        System.out.print("Mobile Number: ");
        long mobileNumber = scanner.nextLong();
        customers[0] = new PremiumCustomer(custId, custName, mobileNumber, 1);

        // Input for Regular Customer
        System.out.println("Enter details for Regular Customer:");
        System.out.print("Customer ID: ");
        custId = scanner.nextInt();
        System.out.print("Customer Name: ");
        scanner.nextLine(); // consume newline
        custName = scanner.nextLine();
        System.out.print("Mobile Number: ");
        mobileNumber = scanner.nextLong();
        customers[1] = new RegularCustomer(custId, custName, mobileNumber, 2);

        double totalBill = 0;
        for (Customer customer : customers) {
            System.out.print("Enter minutes for " + customer.getCustName() + ": ");
            int minutes = scanner.nextInt();
            double bill = customer.calculateBill(minutes);
            totalBill += bill;
            System.out.println("Bill for " + customer.getCustName() + ": " + bill);
        }

        System.out.println("Total Bill Amount: " + totalBill);
        scanner.close();
    }
}

