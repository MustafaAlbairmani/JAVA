import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;

interface IMenuRecommendation {
    void addItem(int itemId, String displayName);
    MenuItem getRecommendedItem();
    void outOfStockItem(int itemId);
    void restockItem(int itemId);
    void makeDealOfTheDayItem(int itemId);
    void rateItem(int itemId, int rating);
}

class MenuItem {
    int itemId;
    String displayName;
    double averageRating;
    int totalRatings;
    boolean inStock;
    boolean isDealOfTheDay;

    public MenuItem(int itemId, String displayName) {
        this.itemId = itemId;
        this.displayName = displayName;
        this.averageRating = 0;
        this.totalRatings = 0;
        this.inStock = true;
        this.isDealOfTheDay = false;
    }

    public void updateRating(int rating) {
        totalRatings++;
        averageRating = ((averageRating * (totalRatings - 1)) + rating) / totalRatings;
    }
}

public class MenuRecommendation implements IMenuRecommendation {
    private Map<Integer, MenuItem> menuItems;
    private PriorityQueue<MenuItem> availableItems;

    public MenuRecommendation() {
        menuItems = new HashMap<>();
        availableItems = new PriorityQueue<>((a, b) -> Double.compare(b.averageRating, a.averageRating));
    }

    @Override
    public void addItem(int itemId, String displayName) {
        menuItems.put(itemId, new MenuItem(itemId, displayName));
    }

    @Override
    public MenuItem getRecommendedItem() {
        if (availableItems.isEmpty()) {
            return null;
        }
        return availableItems.peek();
    }

    @Override
    public void outOfStockItem(int itemId) {
        MenuItem item = menuItems.get(itemId);
        if (item != null) {
            item.inStock = false;
            availableItems.remove(item);
        }
    }

    @Override
    public void restockItem(int itemId) {
        MenuItem item = menuItems.get(itemId);
        if (item != null) {
            item.inStock = true;
            availableItems.add(item);
        }
    }

    @Override
    public void makeDealOfTheDayItem(int itemId) {
        MenuItem item = menuItems.get(itemId);
        if (item != null) {
            item.isDealOfTheDay = true;
            availableItems.add(item);
        }
    }

    @Override
    public void rateItem(int itemId, int rating) {
        MenuItem item = menuItems.get(itemId);
        if (item != null && item.inStock) {
            item.updateRating(rating);
            availableItems.remove(item);
            availableItems.add(item);
        }
    }

    public static void main(String[] args) {
        MenuRecommendation menuRecommendation = new MenuRecommendation();
        menuRecommendation.getRecommendedItem(); // N/A

        menuRecommendation.addItem(1, "Item1");
        menuRecommendation.rateItem(1, 5);
        System.out.println(menuRecommendation.getRecommendedItem()); // 1 Item1 Rating: 5.0

        menuRecommendation.outOfStockItem(1);
        menuRecommendation.rateItem(1, 4);
        menuRecommendation.rateItem(1, 4);
        System.out.println(menuRecommendation.getRecommendedItem()); // N/A
    }
}
