// Class Bread extending Food
class Bread extends Food {
    String type;

    // Constructor
    public Bread(double proteins, double fats, double carbs) {
        this.proteins = proteins;
        this.fats = fats;
        this.carbs = carbs;
        this.tastyScore = 8;
        this.type = "vegetarian";
    }

    @Override
    void getMacroNutrients() {
        System.out.println("A slice of bread has " + this.proteins
                + " gms of protein, " + this.fats + " gms of fats and "
                + this.carbs + " gms of carbohydrates.");
    }
}