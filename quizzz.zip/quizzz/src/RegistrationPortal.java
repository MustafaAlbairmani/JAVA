import java.util.ArrayList;
import java.util.List;

class Student {
    private static int nextId = 1;

    private int id;
    private String name;

    // Constructor
    public Student(String name) {
        this.id = getNextId();
        this.name = name;
    }

    private synchronized static int getNextId() {
        return nextId++;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}

public class RegistrationPortal {
    private static RegistrationPortal instance;
    private List<Student> registeredStudents;

    // Private constructor to enforce singleton pattern
    private RegistrationPortal() {
        registeredStudents = new ArrayList<>();
    }

    // Singleton method to get the instance of RegistrationPortal
    public synchronized static RegistrationPortal getRegistrationPortal() {
        if (instance == null) {
            instance = new RegistrationPortal();
        }
        return instance;
    }

    // Method to register a student
    public synchronized void register(Student student) {
        registeredStudents.add(student);
    }

    // Method to get the registered students
    public synchronized List<Student> getRegisteredStudents() {
        return new ArrayList<>(registeredStudents); // Return a copy to prevent external modification
    }

    // Main method for testing
    public static void main(String[] args) {
        // Example usage
        RegistrationPortal portal = RegistrationPortal.getRegistrationPortal();

        // Create and start threads
        int threadsCount = 2;
        List<Thread> threads = new ArrayList<>();

        for (int i = 0; i < threadsCount; i++) {
            final int threadNumber = i + 1;
            int studentsCount = 3; // For simplicity, you can set the number of students per thread here

            Thread thread = new Thread(() -> {
                for (int j = 0; j < studentsCount; j++) {
                    Student student = new Student("name-" + threadNumber + "-" + (j + 1));
                    portal.register(student);
                }
            });

            threads.add(thread);
            thread.start();
        }

        // Wait for all threads to finish
        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Get registered students
        List<Student> registeredStudents = portal.getRegisteredStudents();
        System.out.println("Registered Students:");
        for (Student student : registeredStudents) {
            System.out.println("id-" + student.getId() + " " + "name-" + student.getName());
        }
    }
}
