// Abstract class Food
abstract class Food {
    double proteins;
    double fats;
    double carbs;
    double tastyScore;

    // Abstract method
    abstract void getMacroNutrients();

    public void getType() {
        System.out.println("This food item is " + ((this instanceof Egg) ? "non-vegetarian" : "vegetarian"));
    }

    public void getTaste() {
        System.out.println("Taste: " + tastyScore);
    }
}
