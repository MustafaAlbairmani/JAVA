import java.util.HashMap;
import java.util.Map;

interface IBankAccountOperation {
    void deposit(double amount);
    void withdraw(double amount);
    double processOperation(String message);
}

class BankOperations implements IBankAccountOperation {
    private double balance;
    
    // Constructor to initialize the balance
    public BankOperations() {
        this.balance = 0;
    }
    
    @Override
    public void deposit(double amount) {
        balance += amount;
    }

    @Override
    public void withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
        }
        // If insufficient balance, withdrawal is canceled, and balance remains unchanged.
    }

    @Override
    public double processOperation(String message) {
        String[] words = message.split("\\s+");
       final double amount = 0;

        // Map keywords to actions
        Map<String, Runnable> actions = new HashMap<>();
        actions.put("show", () -> System.out.println(balance));
        actions.put("see", () -> System.out.println(balance));
        actions.put("deposit", () -> deposit(amount));
        actions.put("put", () -> deposit(amount));
        actions.put("invest", () -> deposit(amount));
        actions.put("transfer", () -> deposit(amount));
        actions.put("withdraw", () -> withdraw(amount));
        actions.put("pull", () -> withdraw(amount));

        for (int i = 0; i < words.length; i++) {
            String word = words[i].toLowerCase();

            // Check if the word is a keyword
            if (actions.containsKey(word)) {
                // If the keyword is related to an amount, extract the amount from the next word
                if (i + 1 < words.length) {
                    try {
                        amount = Double.parseDouble(words[i + 1]);
                        i++; // Move to the next word after the amount
                    } catch (NumberFormatException e) {
                        // Ignore if the next word is not a valid amount
                    }
                }

                // Execute the corresponding action
                actions.get(word).run();
            }
        }

        return balance;
    }
}

public class Main {
    public static void main(String[] args) {
        // Sample usage
        BankOperations bank = new BankOperations();
        System.out.println(bank.processOperation("Deposit 2396"));  // 2396
        System.out.println(bank.processOperation("I want to transfer 3017 dollars to my account"));  // 5413
        System.out.println(bank.processOperation("I want to pull 2300 dollars"));  // 3113
        System.out.println(bank.processOperation("I want to deposit 3980 dollars"));  // 7093
        System.out.println(bank.processOperation("I want to transfer 2811 dollars to my account"));  // 9904
    }
}
