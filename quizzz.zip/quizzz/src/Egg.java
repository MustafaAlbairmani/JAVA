// Class Egg extending Food
class Egg extends Food {
    String type;

    // Constructor
    public Egg(double proteins, double fats, double carbs) {
        this.proteins = proteins;
        this.fats = fats;
        this.carbs = carbs;
        this.tastyScore = 7;
        this.type = "non-vegetarian";
    }

    @Override
    void getMacroNutrients() {
        System.out.println("An egg has " + this.proteins + " gms of protein, "
                + this.fats + " gms of fats and " + this.carbs
                + " gms of carbohydrates.");
    }
}