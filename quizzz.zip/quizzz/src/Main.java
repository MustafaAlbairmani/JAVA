import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = scanner.nextInt();

        for (int i = 0; i < n; i++) {
            String foodType = scanner.next();

            Food foodItem;
            if (foodType.equals("Egg")) {
                double proteins = scanner.nextDouble();
                double fats = scanner.nextDouble();
                double carbs = scanner.nextDouble();
                foodItem = new Egg(proteins, fats, carbs);
            } else if (foodType.equals("Bread")) {
                double proteins = scanner.nextDouble();
                double fats = scanner.nextDouble();
                double carbs = scanner.nextDouble();
                foodItem = new Bread(proteins, fats, carbs);
            } else {
                // Handle other food types if needed
                foodItem = null;
            }

            if (foodItem != null) {
                // Handle method calls
                while (scanner.hasNext()) {
                    String methodName = scanner.next();
                    switch (methodName) {
                        case "getType":
                            foodItem.getType();
                            break;
                        case "getTaste":
                            foodItem.getTaste();
                            break;
                        case "getMacros":
                            foodItem.getMacroNutrients();
                            break;
                    }
                }
            }
        }
    }
}